globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/d79d834fa7634920.js",
      "static/chunks/turbopack-641a1898181fa53e.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/d79d834fa7634920.js",
      "static/chunks/turbopack-6c9654c0d828119a.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/707376a709626df4.js",
    "static/chunks/2b306f3245e1c8db.js",
    "static/chunks/079d5ede7af38810.js",
    "static/chunks/06e05d1b6ea5b5c1.js",
    "static/chunks/turbopack-590784c82abcad33.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];