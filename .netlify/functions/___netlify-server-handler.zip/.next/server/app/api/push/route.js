var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/push/route.js")
R.c("server/chunks/[root-of-the-server]__e748dadc._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.m(73034)
R.m(6322)
module.exports=R.m(6322).exports
